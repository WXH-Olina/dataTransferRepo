// Termm--Fall 2020

#pragma once

#include <glm/glm.hpp>

#include "cs488-framework/CS488Window.hpp"
#include "cs488-framework/OpenGLImport.hpp"
#include "cs488-framework/ShaderProgram.hpp"

#include "maze.hpp"

class A1 : public CS488Window {
public:
	A1();
	virtual ~A1();

protected:
	virtual void init() override;
	virtual void appLogic() override;
	virtual void guiLogic() override;
	virtual void draw() override;
	virtual void cleanup() override;

	virtual bool cursorEnterWindowEvent(int entered) override;
	virtual bool mouseMoveEvent(double xPos, double yPos) override;
	virtual bool mouseButtonInputEvent(int button, int actions, int mods) override;
	virtual bool mouseScrollEvent(double xOffSet, double yOffSet) override;
	virtual bool windowResizeEvent(int width, int height) override;
	virtual bool keyInputEvent(int key, int action, int mods) override;
	
	// Character callback for ImGui text input
	static void charCallback(GLFWwindow* window, unsigned int codepoint);

	glm::vec3 wall_color; // RGB color of the maze walls
	glm::vec3 floor_color; // RGB color of the maze floor (N*N)
	glm::vec3 sphere_color; // RGB color of the avatar
	glm::vec3 sphere_translate; // Translate vector of the sphere. Can be viewed as the current position of the avatar.

private:
	void initGrid();
	void initCube();
	void initSphere();

	// Fields related to the shader and uniforms.
	ShaderProgram m_shader;
	GLint P_uni; // Uniform location for Projection matrix.
	GLint V_uni; // Uniform location for View matrix.
	GLint M_uni; // Uniform location for Model matrix.
	GLint col_uni;   // Uniform location for cube colour.

	// Fields related to grid geometry.
	GLuint m_grid_vao; // Vertex Array Object
	GLuint m_grid_vbo; // Vertex Buffer Object
    
	// Fields related to cube geometry
	GLuint m_cube_vao;
    GLuint m_cube_vbo;
    GLuint m_cube_ebo;

	// Fields related to sphere geometry
	GLuint m_sphere_vao;
	GLuint m_sphere_vbo;
	GLuint m_sphere_ebo;
	int m_sphere_index_count;  // Number of indices for the sphere

	// Matrices controlling the camera and projection.
	glm::mat4 proj;
	glm::mat4 view;

	// Maze data
	Maze* m_maze;
	int m_blockHeight;  // Height of walls in blocks

	// float colour[3];
	int current_col;
	
	// Rotation state
	float m_rotationAngle;     // Current rotation angle in radians
	bool m_isDragging;         // Whether the mouse is currently being dragged
	double m_prevMouseX;       // Previous mouse X position for calculating rotation delta
	float m_rotationVelocity;  // Rotation velocity for persistence (radians per frame)
	
	// Scaling state
	float m_scale;             // Current scale factor for the grid
};
