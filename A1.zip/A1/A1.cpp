// Termm--Fall 2020

#include "A1.hpp" 
#include "cs488-framework/GlErrorCheck.hpp"

#include <iostream>
#include <vector>

#include <sys/types.h>
#include <unistd.h>

#include <imgui/imgui.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

using namespace glm;
using namespace std;

static const size_t DIM = 16;

//----------------------------------------------------------------------------------------
// Constructor
A1::A1()
	: current_col( 0 ), 
	 m_blockHeight( 1 ),
	 wall_color(glm::vec3(1.0f, 0.0f, 0.0f)),
	 floor_color(glm::vec3(0.0f, 1.0f, 0.0f)),
	 sphere_color(glm::vec3(0.0f, 0.0f, 1.0f)),
	 m_sphere_index_count(0),
	 sphere_translate(glm::vec3(0.0f, 0.0f, 0.0f)),
	 m_rotationAngle(0.0f),
	 m_isDragging(false),
	 m_prevMouseX(0.0),
	 m_rotationVelocity(0.0f),
	 m_scale(1.0f)
{
	// colour[0] = 0.0f;
	// colour[1] = 0.0f;
	// colour[2] = 0.0f;
}

//----------------------------------------------------------------------------------------
// Destructor
A1::~A1()
{}

//----------------------------------------------------------------------------------------
/*
 * Called once, at program start.
 */
void A1::init()
{
	// Initialize random number generator
	int rseed=getpid();
	srandom(rseed);
	// Print random number seed in case we want to rerun with
	// same random numbers
	cout << "Random number seed = " << rseed << endl;
	

	// Create and store maze
	m_maze = new Maze(DIM);
	m_maze->digMaze(); // Randomly dig a maze
	m_maze->printMaze(); // Print the "X " version of the maze for reference
	
	// Find entrance in first row (row 0) and place avatar there by initializing the translate vec
	for(int j = 0; j < DIM; ++j) {
		if(m_maze->getValue(0, j) == 0) {
			sphere_translate = glm::vec3(j, 1, 0); // +1 for the ring
			break;  // Found the entrance
		}
	}
	
	// Set the background colour.
	glClearColor( 0.3, 0.5, 0.7, 1.0 );

	// Build the shader
	m_shader.generateProgramObject();
	m_shader.attachVertexShader(
		getAssetFilePath( "VertexShader.vs" ).c_str() );
	m_shader.attachFragmentShader(
		getAssetFilePath( "FragmentShader.fs" ).c_str() );
	m_shader.link();

	// Set up the uniforms
	P_uni = m_shader.getUniformLocation( "P" );
	V_uni = m_shader.getUniformLocation( "V" );
	M_uni = m_shader.getUniformLocation( "M" );
	col_uni = m_shader.getUniformLocation( "colour" );

	initGrid();
	initCube();
	initSphere();

	// Set up initial view and projection matrices (need to do this here,
	// since it depends on the GLFW window being set up correctly).
	view = glm::lookAt( 
		glm::vec3( 0.0f, 2.*float(DIM)*2.0*M_SQRT1_2, float(DIM)*2.0*M_SQRT1_2 ),
		glm::vec3( 0.0f, 0.0f, 0.0f ),
		glm::vec3( 0.0f, 1.0f, 0.0f ) );

	proj = glm::perspective( 
		glm::radians( 30.0f ),
		float( m_framebufferWidth ) / float( m_framebufferHeight ),
		1.0f, 1000.0f );
	
	// Register character callback for ImGui text input
	glfwSetCharCallback(m_window, A1::charCallback);
}

//----------------------------------------------------------------------------------------
// AI-Generated: This function was created with assistance from GitHub Copilot
void A1::initCube() // Build the "standard cube"
{
    // Define vertices for a unit cube with one corner at the origin
    float vertices[] = {
        // Front face (z = 1)
        0.0f, 0.0f, 1.0f,  // 0
        1.0f, 0.0f, 1.0f,  // 1
        1.0f, 1.0f, 1.0f,  // 2
        0.0f, 1.0f, 1.0f,  // 3
        // Back face (z = 0)
        0.0f, 0.0f, 0.0f,  // 4
        1.0f, 0.0f, 0.0f,  // 5
        1.0f, 1.0f, 0.0f,  // 6
        0.0f, 1.0f, 0.0f   // 7
    };

    // Define indices for the 6 faces (2 triangles per face)
    GLuint indices[] = {
        // Front face
        0, 1, 2,
        2, 3, 0,
        // Back face
        5, 4, 7,
        7, 6, 5,
        // Left face
        4, 0, 3,
        3, 7, 4,
        // Right face
        1, 5, 6,
        6, 2, 1,
        // Top face
        3, 2, 6,
        6, 7, 3,
        // Bottom face
        4, 5, 1,
        1, 0, 4
    };

    // Create the vertex array to record buffer assignments.
    glGenVertexArrays( 1, &m_cube_vao );
    glBindVertexArray( m_cube_vao );

    // Create the cube vertex buffer
    glGenBuffers( 1, &m_cube_vbo );
    glBindBuffer( GL_ARRAY_BUFFER, m_cube_vbo );
    glBufferData( GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW );

    // Specify the means of extracting the position values properly.
    GLint posAttrib = m_shader.getAttribLocation( "position" );
    glEnableVertexAttribArray( posAttrib );
    glVertexAttribPointer( posAttrib, 3, GL_FLOAT, GL_FALSE, 0, nullptr );

    // Create the index buffer
    glGenBuffers( 1, &m_cube_ebo );
    glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, m_cube_ebo );
    glBufferData( GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW );

    // Reset state to prevent rogue code from messing with *my* stuff!
    glBindVertexArray( 0 );
    glBindBuffer( GL_ARRAY_BUFFER, 0 );
    glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, 0 );

    CHECK_GL_ERRORS;
}

//----------------------------------------------------------------------------------------
// AI-Generated: This function was created with assistance from GitHub Copilot/ChatGPT
void A1::initSphere()
{
    const float radius = 0.5f;
    const glm::vec3 center(0.5f, 0.5f, 0.5f);
    const int stacks = 20;  // Number of vertical divisions
    const int slices = 20;  // Number of horizontal divisions
    
    vector<float> vertices;
    vector<GLuint> indices;
    
    // Generate vertices
    for(int i = 0; i <= stacks; ++i) {
        float theta = (float)i / stacks * M_PI;  // Angle from top to bottom
        float sinTheta = sin(theta);
        float cosTheta = cos(theta);
        
        for(int j = 0; j <= slices; ++j) {
            float phi = (float)j / slices * 2.0f * M_PI;  // Angle around the sphere
            float sinPhi = sin(phi);
            float cosPhi = cos(phi);
            
            // Vertex position relative to center
            float x = radius * sinTheta * cosPhi;
            float y = radius * cosTheta;
            float z = radius * sinTheta * sinPhi;
            
            // Add center offset
            vertices.push_back(center.x + x);
            vertices.push_back(center.y + y);
            vertices.push_back(center.z + z);
        }
    }
    
    // Generate indices
    for(int i = 0; i < stacks; ++i) {
        for(int j = 0; j < slices; ++j) {
            int first = i * (slices + 1) + j;
            int second = first + slices + 1;
            
            // First triangle
            indices.push_back(first);
            indices.push_back(second);
            indices.push_back(first + 1);
            
            // Second triangle
            indices.push_back(first + 1);
            indices.push_back(second);
            indices.push_back(second + 1);
        }
    }
    
    // Create VAO
    glGenVertexArrays(1, &m_sphere_vao);
    glBindVertexArray(m_sphere_vao);
    
    // Create VBO
    glGenBuffers(1, &m_sphere_vbo);
    glBindBuffer(GL_ARRAY_BUFFER, m_sphere_vbo);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), vertices.data(), GL_STATIC_DRAW);
    
    // Set up vertex attribute
    GLint posAttrib = m_shader.getAttribLocation("position");
    glEnableVertexAttribArray(posAttrib);
    glVertexAttribPointer(posAttrib, 3, GL_FLOAT, GL_FALSE, 0, nullptr);
    
    // Create EBO
    glGenBuffers(1, &m_sphere_ebo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_sphere_ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(GLuint), indices.data(), GL_STATIC_DRAW);
    
    // Store the index count
    m_sphere_index_count = indices.size();
    
    // Reset state
    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    
    CHECK_GL_ERRORS;
}

void A1::initGrid()
{
	size_t sz = 3 * 2 * 2 * (DIM+3);

	float *verts = new float[ sz ];
	size_t ct = 0;
	for( int idx = 0; idx < DIM+3; ++idx ) {
		verts[ ct ] = -1;
		verts[ ct+1 ] = 0;
		verts[ ct+2 ] = idx-1;
		verts[ ct+3 ] = DIM+1;
		verts[ ct+4 ] = 0;
		verts[ ct+5 ] = idx-1;
		ct += 6;

		verts[ ct ] = idx-1;
		verts[ ct+1 ] = 0;
		verts[ ct+2 ] = -1;
		verts[ ct+3 ] = idx-1;
		verts[ ct+4 ] = 0;
		verts[ ct+5 ] = DIM+1;
		ct += 6;
	}

	// Create the vertex array to record buffer assignments.
	glGenVertexArrays( 1, &m_grid_vao );
	glBindVertexArray( m_grid_vao );

	// Create the cube vertex buffer
	glGenBuffers( 1, &m_grid_vbo );
	glBindBuffer( GL_ARRAY_BUFFER, m_grid_vbo );
	glBufferData( GL_ARRAY_BUFFER, sz*sizeof(float), verts, GL_STATIC_DRAW );

	// Specify the means of extracting the position values properly.
	GLint posAttrib = m_shader.getAttribLocation( "position" );
	glEnableVertexAttribArray( posAttrib );
	glVertexAttribPointer( posAttrib, 3, GL_FLOAT, GL_FALSE, 0, nullptr );

	// Reset state to prevent rogue code from messing with *my* stuff!
	glBindVertexArray( 0 );
	glBindBuffer( GL_ARRAY_BUFFER, 0 );
	glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, 0 );

	// OpenGL has the buffer now, there's no need for us to keep a copy.
	delete [] verts;

	CHECK_GL_ERRORS;
}

//----------------------------------------------------------------------------------------
/*
 * Called once per frame, before guiLogic().
 */
void A1::appLogic()
{
	// Apply rotation velocity for persistence effect
	if (!m_isDragging && m_rotationVelocity != 0.0f) {
		m_rotationAngle += m_rotationVelocity;
	}
}

//----------------------------------------------------------------------------------------
/*
 * Called once per frame, after appLogic(), but before the draw() method.
 */
void A1::guiLogic()
{
	// We already know there's only going to be one window, so for 
	// simplicity we'll store button states in static local variables.
	// If there was ever a possibility of having multiple instances of
	// A1 running simultaneously, this would break; you'd want to make
	// this into instance fields of A1.
	static bool showTestWindow(false);
	static bool showDebugWindow(true);

	ImGuiWindowFlags windowFlags(ImGuiWindowFlags_AlwaysAutoResize);
	float opacity(0.5f);

	ImGui::Begin("Debug Window", &showDebugWindow, ImVec2(100,100), opacity, windowFlags);
		if( ImGui::Button( "Quit Application" ) ) {
			glfwSetWindowShouldClose(m_window, GL_TRUE);
		}

		if( ImGui::Button( "Reset" ) ) {
			current_col = 0;
			m_blockHeight = 1;
			wall_color = glm::vec3(1.0f, 0.0f, 0.0f);
			floor_color = glm::vec3(0.0f, 1.0f, 0.0f);
			sphere_color = glm::vec3(0.0f, 0.0f, 1.0f);
			// sphere_translate = glm::vec3(0.0f, 0.0f, 0.0f); // No need to reset the sphere location
			m_rotationAngle = 0.0f;
			m_isDragging = false;
			m_prevMouseX = 0.0;
			m_rotationVelocity = 0.0f;
			m_scale = 1.0f;
		}

		if( ImGui::Button( "Dig" ) ) {
			delete m_maze;
			
			m_maze = new Maze(DIM);
			m_maze->digMaze();
			m_maze->printMaze();
			
			for(int j = 0; j < DIM; ++j) {
				if(m_maze->getValue(0, j) == 0) {
					sphere_translate = glm::vec3(j, 1, 0);
					break;
				}
			}
		}

		// Eventually you'll create multiple colour widgets with
		// radio buttons.  If you use PushID/PopID to give them all
		// unique IDs, then ImGui will be able to keep them separate.
		// This is unnecessary with a single colour selector and
		// radio button, but I'm leaving it in as an example.

		// Prefixing a widget name with "##" keeps it from being
		// displayed.

		ImGui::PushID( 0 );
		static int prev_col = -1;
		static float colour[3] = { 0.0f, 0.0f, 0.0f };
		
		// Update colour array when selection changes
		if (current_col != prev_col) {
			prev_col = current_col;
			if (current_col == 0) {
				colour[0] = wall_color.r;
				colour[1] = wall_color.g;
				colour[2] = wall_color.b;
			} else if (current_col == 1) {
				colour[0] = floor_color.r;
				colour[1] = floor_color.g;
				colour[2] = floor_color.b;
			} else if (current_col == 2) {
				colour[0] = sphere_color.r;
				colour[1] = sphere_color.g;
				colour[2] = sphere_color.b;
			}
		}
		
		// Update the selected color based on ColorEdit3 changes
		if (ImGui::ColorEdit3( "Colour", colour )) {
			if (current_col == 0) {
				wall_color = glm::vec3(colour[0], colour[1], colour[2]);
			} else if (current_col == 1) {
				floor_color = glm::vec3(colour[0], colour[1], colour[2]);
			} else if (current_col == 2) {
				sphere_color = glm::vec3(colour[0], colour[1], colour[2]);
			}
		}
		
		ImGui::SameLine();
		if( ImGui::RadioButton( "Wall", &current_col, 0 ) ) {
			// Nothing to do here. Color change is handled by ColorEdit3 before.
		}
		ImGui::SameLine();
		if( ImGui::RadioButton( "Floor", &current_col, 1 ) ) {
		}
		ImGui::SameLine();
		if( ImGui::RadioButton( "Avatar", &current_col, 2 ) ) {
		}
		ImGui::PopID();

/*
		// For convenience, you can uncomment this to show ImGui's massive
		// demonstration window right in your application.  Very handy for
		// browsing around to get the widget you want.  Then look in 
		// shared/imgui/imgui_demo.cpp to see how it's done.
		if( ImGui::Button( "Test Window" ) ) {
			showTestWindow = !showTestWindow;
		}
*/

		ImGui::Text( "Framerate: %.1f FPS", ImGui::GetIO().Framerate );

	ImGui::End();

	if( showTestWindow ) {
		ImGui::ShowTestWindow( &showTestWindow );
	}
}

//----------------------------------------------------------------------------------------
/*
 * Called once per frame, after guiLogic().
 */
void A1::draw()
{
	// Create a global transformation for the model (centre it).
	mat4 W;
	// Apply transformations: scale, rotate around Y-axis, then translate to center
	W = glm::rotate( W, m_rotationAngle, vec3(0, 1, 0) );
	W = glm::scale( W, vec3(m_scale, m_scale, m_scale) );
	W = glm::translate( W, vec3( -float(DIM)/2.0f, 0, -float(DIM)/2.0f ) );

	m_shader.enable();
		glEnable( GL_DEPTH_TEST );

		glUniformMatrix4fv( P_uni, 1, GL_FALSE, value_ptr( proj ) );
		glUniformMatrix4fv( V_uni, 1, GL_FALSE, value_ptr( view ) );
		glUniformMatrix4fv( M_uni, 1, GL_FALSE, value_ptr( W ) );

		// Draw (default) grid
		glBindVertexArray( m_grid_vao );
		glUniform3f( col_uni, 1, 1, 1 );
		glDrawArrays( GL_LINES, 0, (3+DIM)*4 );

		// Draw the floor (covers the NxN portion of the grid)
		// AI-Generated: The following codes (line 445-478) was created with assistance from GitHub Copilot
		float floorVertices[] = {
			0.0f, 0.0f, 0.0f,      // 0: front-left
			DIM, 0.0f, 0.0f,       // 1: front-right
			DIM, 0.0f, DIM,        // 2: back-right
			0.0f, 0.0f, DIM        // 3: back-left
		};
		
		GLuint floorIndices[] = {
			0, 1, 2,  // First triangle
			2, 3, 0   // Second triangle
		};
		
		GLuint floorVAO, floorVBO, floorEBO;
		glGenVertexArrays(1, &floorVAO);
		glBindVertexArray(floorVAO);
		
		glGenBuffers(1, &floorVBO);
		glBindBuffer(GL_ARRAY_BUFFER, floorVBO);
		glBufferData(GL_ARRAY_BUFFER, sizeof(floorVertices), floorVertices, GL_STATIC_DRAW);
		
		GLint posAttrib = m_shader.getAttribLocation("position");
		glEnableVertexAttribArray(posAttrib);
		glVertexAttribPointer(posAttrib, 3, GL_FLOAT, GL_FALSE, 0, nullptr);
		
		glGenBuffers(1, &floorEBO);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, floorEBO);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(floorIndices), floorIndices, GL_STATIC_DRAW);
		
		glUniform3f(col_uni, floor_color.r, floor_color.g, floor_color.b);  // Green color for floor
		glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
		
		glDeleteBuffers(1, &floorVBO);
		glDeleteBuffers(1, &floorEBO);
		glDeleteVertexArrays(1, &floorVAO);

		// Draw the maze walls (multiple blocks high)
		glBindVertexArray( m_cube_vao ); // use the cube shape for all subsequent draw calls
		for( int i = 0; i < DIM; ++i ) {
			for( int j = 0; j < DIM; ++j ) {
				if( m_maze->getValue(i, j) == 1 ) {
					// Draw stacked cubes for this wall position
					for( int h = 0; h < m_blockHeight; ++h ) { // m_blockHeight controlled by keys.
						mat4 cubeTransform = W;
						cubeTransform = glm::translate( cubeTransform, vec3(j, h, i) );
						
						glUniformMatrix4fv( M_uni, 1, GL_FALSE, value_ptr( cubeTransform ) );
						glUniform3f( col_uni, wall_color.x, wall_color.y, wall_color.z );  // Use wall_color
						glDrawElements( GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0 );
					}
				}
			}
		}

		// Draw an Avatar (translated by sphere_translate)
		mat4 sphereTransform = W;
		sphereTransform = glm::translate( sphereTransform, sphere_translate );
		glUniformMatrix4fv( M_uni, 1, GL_FALSE, value_ptr( sphereTransform ) );

		glBindVertexArray( m_sphere_vao );
		glUniform3f( col_uni, sphere_color.x, sphere_color.y, sphere_color.z );  // Use sphere_color
		glDrawElements( GL_TRIANGLES, m_sphere_index_count, GL_UNSIGNED_INT, 0 );

		
		// Highlight the active square.
	m_shader.disable();

	// Restore defaults
	glBindVertexArray( 0 );

	CHECK_GL_ERRORS;
}

//----------------------------------------------------------------------------------------
/*
 * Called once, after program is signaled to terminate.
 */
void A1::cleanup()
{
	delete m_maze;
}

//----------------------------------------------------------------------------------------
/*
 * Event handler.  Handles cursor entering the window area events.
 */
bool A1::cursorEnterWindowEvent (
		int entered
) {
	bool eventHandled(false);

	// Fill in with event handling code...

	return eventHandled;
}

//----------------------------------------------------------------------------------------
/*
 * Event handler.  Handles mouse cursor movement events.
 */
bool A1::mouseMoveEvent(double xPos, double yPos) 
{
	bool eventHandled(false);

	if (!ImGui::IsMouseHoveringAnyWindow()) {
		if (m_isDragging) {
			// Calculate the change in mouse X position
			double deltaX = xPos - m_prevMouseX;
			
			// Convert mouse movement to rotation angle
			// Scale factor determines sensitivity (radians per pixel)
			float rotationSpeed = 0.01f;
			float deltaRotation = deltaX * rotationSpeed;
			m_rotationAngle += deltaRotation;
			
			// Store velocity for persistence (this will be the last velocity when released)
			m_rotationVelocity = deltaRotation;
			
			// Update previous mouse position
			m_prevMouseX = xPos;
			
			eventHandled = true;
		}
	}

	return eventHandled;
}

//----------------------------------------------------------------------------------------
/*
 * Event handler.  Handles mouse button events.
 */
bool A1::mouseButtonInputEvent(int button, int actions, int mods) {
	bool eventHandled(false);

	if (!ImGui::IsMouseHoveringAnyWindow()) {
		if (button == GLFW_MOUSE_BUTTON_LEFT) {
			if (actions == GLFW_PRESS) {
				// Start dragging - record current mouse position and stop persistence
				double xpos, ypos;
				glfwGetCursorPos(m_window, &xpos, &ypos);
				m_prevMouseX = xpos;
				m_isDragging = true;
				m_rotationVelocity = 0.0f;  // Stop any existing persistence rotation
				eventHandled = true;
			} else if (actions == GLFW_RELEASE) {
				// Stop dragging - velocity is already set from last mouse move
				// If mouse was moving, rotation will continue with persistence
				m_isDragging = false;
				eventHandled = true;
			}
		}
	}

	return eventHandled;
}

//----------------------------------------------------------------------------------------
/*
 * Event handler.  Handles mouse scroll wheel events.
 */
bool A1::mouseScrollEvent(double xOffSet, double yOffSet) {
	bool eventHandled(false);

	// Zoom in or out.
	if (!ImGui::IsMouseHoveringAnyWindow()) {
		// Scale factor per scroll notch
		float scaleSpeed = 0.1f;
		
		// Adjust scale based on scroll direction
		// Positive yOffSet = scroll up = zoom in (bigger)
		// Negative yOffSet = scroll down = zoom out (smaller)
		m_scale += yOffSet * scaleSpeed;
		
		// Constrain scale to reasonable limits
		const float MIN_SCALE = 0.1f;  // Don't let it get too small
		const float MAX_SCALE = 3.0f;  // Don't let it get too big
		
		if (m_scale < MIN_SCALE) {
			m_scale = MIN_SCALE;
		} else if (m_scale > MAX_SCALE) {
			m_scale = MAX_SCALE;
		}
		
		eventHandled = true;
	}

	return eventHandled;
}

//----------------------------------------------------------------------------------------
/*
 * Event handler.  Handles window resize events.
 */
bool A1::windowResizeEvent(int width, int height) {
	bool eventHandled(false);

	// Fill in with event handling code...

	return eventHandled;
}

//----------------------------------------------------------------------------------------
/*
 * Event handler.  Handles key input events.
 */
bool A1::keyInputEvent(int key, int action, int mods) {
	bool eventHandled(false);

	// Fill in with event handling code...
	if( action == GLFW_PRESS ) {
		// Control the height of walls
		if( key == GLFW_KEY_SPACE ) {
			// Grow walls
			m_blockHeight++;
			eventHandled = true;
		}
		else if( key == GLFW_KEY_BACKSPACE ) {
			// Shrink walls (minimum 1 block)
			if( m_blockHeight > 1 ) {
				m_blockHeight--;
			} 
			eventHandled = true;
		}
		else if( key == GLFW_KEY_Q ) {
			// Quit application
			glfwSetWindowShouldClose(m_window, GL_TRUE);
			eventHandled = true;
		}
		else if( key == GLFW_KEY_R ) {
			// Reset all parameters to initial state
			current_col = 0;
			m_blockHeight = 1;
			wall_color = glm::vec3(1.0f, 0.0f, 0.0f);
			floor_color = glm::vec3(0.0f, 1.0f, 0.0f);
			sphere_color = glm::vec3(0.0f, 0.0f, 1.0f);
			// sphere_translate = glm::vec3(0.0f, 0.0f, 0.0f); // No need to reset the sphere
			m_rotationAngle = 0.0f;
			m_isDragging = false;
			m_prevMouseX = 0.0;
			m_rotationVelocity = 0.0f;
			m_scale = 1.0f;
			eventHandled = true;
		}
		else if( key == GLFW_KEY_D ) {
			delete m_maze;
			m_maze = new Maze(DIM);
			m_maze->digMaze();
			m_maze->printMaze();
			
			for(int j = 0; j < DIM; ++j) {
				if(m_maze->getValue(0, j) == 0) {
					sphere_translate = glm::vec3(j, 1, 0);
					break;
				}
			}
			eventHandled = true;
		}
		// Arrow keys for Avatar movement
		else if( key == GLFW_KEY_UP ) {
			// Move left (decrease x)
			int newX = (int)sphere_translate.x - 1;
			int z = (int)sphere_translate.z;
			if( newX >= 0 && newX < DIM ) {
				if( mods & GLFW_MOD_SHIFT ) {
					// Shift held: remove wall and move
					sphere_translate.x = newX;
					m_maze->setValue(z, newX, 0);
					eventHandled = true;
				} else if( m_maze->getValue(z, newX) == 0 ) {
					// Normal movement: only move if no wall
					sphere_translate.x = newX;
					eventHandled = true;
				}
			}
		}
		else if( key == GLFW_KEY_DOWN ) {
			// Move right (increase x)
			int newX = (int)sphere_translate.x + 1;
			int z = (int)sphere_translate.z;
			if( newX >= 0 && newX < DIM ) {
				if( mods & GLFW_MOD_SHIFT ) {
					// Shift held: remove wall and move
					sphere_translate.x = newX;
					m_maze->setValue(z, newX, 0);
					eventHandled = true;
				} else if( m_maze->getValue(z, newX) == 0 ) {
					// Normal movement: only move if no wall
					sphere_translate.x = newX;
					eventHandled = true;
				}
			}
		}
		else if( key == GLFW_KEY_RIGHT ) {
			// Move up (increase z)
			int x = (int)sphere_translate.x;
			int newZ = (int)sphere_translate.z + 1;
			if( newZ >= 0 && newZ < DIM ) {
				if( mods & GLFW_MOD_SHIFT ) {
					// Shift held: remove wall and move
					sphere_translate.z = newZ;
					m_maze->setValue(newZ, x, 0);
					eventHandled = true;
				} else if( m_maze->getValue(newZ, x) == 0 ) {
					// Normal movement: only move if no wall
					sphere_translate.z = newZ;
					eventHandled = true;
				}
			}
		}
		else if( key == GLFW_KEY_LEFT ) {
			// Move down (decrease z)
			int x = (int)sphere_translate.x;
			int newZ = (int)sphere_translate.z - 1;
			if( newZ >= 0 && newZ < DIM ) {
				if( mods & GLFW_MOD_SHIFT ) {
					// Shift held: remove wall and move
					sphere_translate.z = newZ;
					m_maze->setValue(newZ, x, 0);
					eventHandled = true;
				} else if( m_maze->getValue(newZ, x) == 0 ) {
					// Normal movement: only move if no wall
					sphere_translate.z = newZ;
					eventHandled = true;
				}
			}
		}
	}

	return eventHandled;
}

//----------------------------------------------------------------------------------------
/*
 * Character input callback. Forwards character input to ImGui.
 */
void A1::charCallback(GLFWwindow* window, unsigned int codepoint) {
	ImGuiIO& io = ImGui::GetIO();
	io.AddInputCharacter(codepoint);
}


//My notes 1: why ColorEdit3 cannot receive typed characters? GLFW windows handle the events, including those
// should be fed into ImGui, but it does not handle the character input callbacks.
//My notes 2: pick the world coords, then all translation/rotation/scaling can be achieved through WCS. 