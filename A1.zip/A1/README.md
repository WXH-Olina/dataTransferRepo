# Compilation:
0. Ensure that `pwd` is `A1/`
1. `premake4 gmake`
2. `make`
3. `./A1`
Now you can see the maze game.

# Manual
1. About the height of the wall: I set the minimum height to 1 instead of 0.1.
2. About the persistence: I assume that the maze won't stop rotating until next mouse click, i.e., there is no friction in the environment.
3. About the arrow key: right/left changes z and up/down changes x.
4. About the color difference: I assume that the color difference imply difference among default colors, which means that the program won't prevent users from setting all colors same manually.